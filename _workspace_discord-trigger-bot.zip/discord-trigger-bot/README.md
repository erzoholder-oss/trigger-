# Discord Trigger-Response Bot

A lightweight selfbot automation script that watches a specific Discord channel for a trigger message and automatically responds with a configured reply.

---

## Requirements

- Node.js v16 or higher (bot-hosting.net supports this)
- A Discord account token
- A target channel ID

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Configure your `.env` file

Open `.env` and fill in the values:

| Variable           | Description                                              | Example                          |
|--------------------|----------------------------------------------------------|----------------------------------|
| `TOKEN`            | Your Discord account token                               | `MTExxx...`                      |
| `CHANNEL_ID`       | The ID of the channel to monitor                         | `1234567890123456789`            |
| `TRIGGER_MESSAGE`  | The word/phrase that triggers the response               | `hello`                          |
| `RESPONSE_MESSAGE` | The message the script sends when triggered              | `Hey there!`                     |
| `CASE_SENSITIVE`   | `true` = match exactly as typed, `false` = ignore case   | `false`                          |
| `EXACT_MATCH`      | `true` = full message must match, `false` = partial match| `false`                          |

### 3. Run the script

```bash
npm start
# or
node index.js
```

---

## How to Get Your Discord Token

1. Open Discord in your **browser** (not the app)
2. Press `F12` to open DevTools
3. Go to the **Network** tab
4. Press `Ctrl+R` to reload
5. Filter by `api` and look for any request
6. In the **Request Headers**, find `Authorization` — that value is your token

> ⚠️ **Warning:** Never share your token with anyone. It gives full access to your account.

---

## How to Get a Channel ID

1. Open Discord
2. Go to **Settings → Advanced → Enable Developer Mode**
3. Right-click the channel you want to monitor
4. Click **Copy Channel ID**

---

## Deploying to bot-hosting.net

1. Upload all files (`index.js`, `package.json`, `.env`) to your bot-hosting.net panel
2. Set the **startup command** to: `node index.js`
3. Make sure **Node.js** runtime is selected
4. Start the bot from the panel

---

## Example `.env`

```env
TOKEN=your_discord_token_here
CHANNEL_ID=1234567890123456789
TRIGGER_MESSAGE=!ping
RESPONSE_MESSAGE=Pong! 🏓
CASE_SENSITIVE=false
EXACT_MATCH=true
```

In this example, whenever someone sends exactly `!ping` (case-insensitive) in the configured channel, the script will reply with `Pong! 🏓`.

---

## ⚠️ Disclaimer

Using selfbots (user account automation) is against Discord's Terms of Service. Use this script at your own risk.
